<script lang="ts" setup>
const store = useMainStore()
const runtimeConfig = useRuntimeConfig()
const showList = ref<boolean>(false)

const isAdmin = computed(() => store.admin)
const authorization = computed(() => store.rawAuthorization)
const pluginList = computed(() => store.cache?.plugin_list || {})
const pageLoginConfig = computed(() => store.cache?.config_page_login)
const systemName = computed(() => store.system_name || '贴吧云签到')

const route = useRoute()
const state = reactive<{
    navs: { name: string; to: string; routeName: string; active: boolean; show: boolean; plugin_name_backend?: string; sort: number }[]
}>({
    navs: [
        { name: '首页', to: '/', routeName: 'index', active: true, show: true, sort: 0 },
        { name: '百度账号管理', to: '/accounts', routeName: 'accounts', active: false, show: true, sort: 2 },
        { name: '用户管理', to: '/admin/user', routeName: 'admin-user', active: false, show: true, sort: 4 },
        { name: '系统管理', to: '/admin/system', routeName: 'admin-system', active: false, show: true, sort: 5 },
        { name: '登录', to: '/signin', routeName: 'signin', active: false, show: true, sort: 7 },
        { name: '注册', to: '/signup', routeName: 'signup', active: false, show: true, sort: 8 },
        { name: '找回密码', to: '/reset-password', routeName: 'reset-password', active: false, show: true, sort: 9 },
        { name: '接口控制', to: '/add-base-path', routeName: 'add-base-path', active: false, show: true, sort: 10 }
    ]
})

const wholeRouteName = computed(() => state.navs.map((x) => x.routeName))
const activeNavs = computed(() => state.navs.filter((x) => x.active))

const updateNavStatus = () => {
    const routeSet = new Set(state.navs.map((n) => n.routeName))
    const tmpNavs = Object.fromEntries(state.navs.map((nav) => [nav.routeName, nav]))
    for (const plugin of Object.values(pluginList.value)) {
        if (plugin?.plugin_name_fe && !routeSet.has(plugin.plugin_name_fe)) {
            tmpNavs[`plugin-${plugin.plugin_name_fe}`] = {
                name: plugin.plugin_name_cn_short,
                to: `/plugin/${plugin.plugin_name_fe}`,
                routeName: `plugin-${plugin.plugin_name_fe}`,
                plugin_name_backend: plugin.name,
                active: false,
                show: true,
                sort: 3
            }
        }
    }
    state.navs = Object.values(tmpNavs).sort((a, b) => (a.sort === b.sort ? (a.routeName > b.routeName ? 1 : -1) : a.sort > b.sort ? 1 : -1))
    for (const i in state.navs) {
        if (!state.navs[i]) {
            continue
        }
        switch (state.navs[i].routeName) {
            case 'signin':
                state.navs[i].active = authorization.value === ''
                break
            case 'add-base-path':
                state.navs[i].active = authorization.value === '' && runtimeConfig.public.NUXT_BASE_PATH === ''
                break
            case 'signup':
                state.navs[i].active = !!((authorization.value === '' && pageLoginConfig.value?.enabled_signup) || false)
                break
            case 'reset-password':
                state.navs[i].active = authorization.value === '' || false
                break
            case 'admin-user':
            case 'admin-system':
                state.navs[i].active = authorization.value !== '' && isAdmin.value
                break
            default:
                if (state.navs[i].routeName?.startsWith('plugin')) {
                    state.navs[i].active = pluginList.value?.[state.navs[i].plugin_name_backend || '']?.status || false
                } else {
                    state.navs[i].active = authorization.value !== ''
                }
        }
    }
}

watch([isAdmin, authorization], updateNavStatus)
watch(pluginList, updateNavStatus, { deep: true })
watch(pageLoginConfig, updateNavStatus, { deep: true })

const isSystemAdminPage = computed(() => (route.name || '').toString().startsWith('admin-system-') && (route.fullPath || '').startsWith('/admin/system/'))

useHeadSafe({
    title: computed(() => {
        const routeName = isSystemAdminPage.value ? 'admin-system' : route.name?.toString() || ''
        const tmpIndex = wholeRouteName.value.indexOf(routeName)
        if (tmpIndex < 0) {
            return (route.name || '404')?.toString() + ' - ' + systemName.value
        } else {
            return (state.navs[tmpIndex]?.name || '404') + ' - ' + systemName.value
        }
    })
})

updateNavStatus()
</script>

<template>
    <div id="side-list" class="select-none" v-show="wholeRouteName.includes(route.name?.toString() || '') || isSystemAdminPage">
        <ClientOnly>
            <div class="md:hidden">
                <template v-for="nav in activeNavs" :key="nav.routeName">
                    <NuxtLink
                        v-if="nav.show"
                        :class="{
                            block: true,
                            'px-5': true,
                            'mx-1': true,
                            'md:-mx-5': true,
                            'rounded-full': true,
                            'transition-colors': true,
                            'hover:bg-sky-500': true,
                            'bg-sky-500 text-gray-100': route.name === nav.routeName || (nav.routeName === 'admin-system' && isSystemAdminPage),
                            'text-black': route.name !== nav.routeName,
                            'hover:text-gray-100': true,
                            'dark:text-gray-100': true,
                            'sidelist-in my-1': showList && route.name !== nav.routeName,
                            'sidelist-out': !showList && route.name !== nav.routeName && !(nav.routeName === 'admin-system' && isSystemAdminPage)
                        }"
                        :to="nav.routeName === 'admin-system' && isSystemAdminPage ? route.fullPath : nav.to"
                        @click="showList = !showList"
                    >
                        <div class="py-2 flex justify-between gap-2">
                            <span class="inline-bolck truncate max-w-[60%] 3xs:max-w-[80%]">{{ nav.name }}</span>
                            <uno-icon class="i-bi:list" style="height: 1.5rem; width: 1.5rem" v-show="!showList && (route.name === nav.routeName || (nav.routeName === 'admin-system' && isSystemAdminPage))" />
                        </div>
                    </NuxtLink>
                </template>
            </div>
            <NuxtLink class="hidden md:block group w-full" v-for="nav in activeNavs" :key="nav.routeName" v-show="nav.show" :to="nav.routeName === 'admin-system' && isSystemAdminPage ? route.fullPath : nav.to">
                <div
                    :class="{
                        'max-w-full': true,
                        'inline-block': true,
                        'my-1': true,
                        'px-5': true,
                        'mx-1': true,
                        'rounded-full': true,
                        'transition-colors': true,
                        'group-hover:bg-sky-500': true,
                        'bg-sky-500 text-gray-100': route.name === nav.routeName || (nav.routeName === 'admin-system' && isSystemAdminPage),
                        'text-black': route.name !== nav.routeName,
                        'group-hover:text-gray-100': true,
                        'dark:text-gray-100': true,
                        'py-2': true
                    }"
                >
                    <div class="inline-bolck truncate">{{ nav.name }}</div>
                </div>
            </NuxtLink>
        </ClientOnly>
    </div>
</template>

<style scoped>
.sidelist-out {
    max-height: 0;
    opacity: 0;
    transition:
        max-height 0.1s linear,
        opacity 0.1s linear;
    overflow: hidden;
}

.sidelist-in {
    max-height: 2.5rem;
    opacity: 1;
    transition:
        max-height 0.1s linear,
        opacity 0.1s linear;
    overflow: hidden;
}

.sidelist-in,
.sidelist-out {
    will-change: opacity, transform;
}
</style>
